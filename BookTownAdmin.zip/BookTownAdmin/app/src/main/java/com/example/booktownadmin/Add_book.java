package com.example.booktownadmin;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.media.Image;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class Add_book extends AppCompatActivity {
    ImageView iv;
    String cover_page;
    EditText btitle,bisbn,bauthor,bcategory,blang,bedition,bpublis;
    private final int Gallery_Code = 1000;
    Uri selectedImageUri;
    Bitmap bitmap= null;
    private String selectedImagePath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_book);

        iv =findViewById(R.id.cover_page);

        btitle = findViewById(R.id.Add_book_title);
        bisbn = findViewById(R.id.Add_book_isbn);
        bauthor = findViewById(R.id.Add_book_author);
        bcategory = findViewById(R.id.Add_book_category);
        blang = findViewById(R.id.Add_book_lang);
        bedition = findViewById(R.id.Add_book_edition);
        bpublis = findViewById(R.id.Add_book_publis_date);
    }

    public void opengallery(View view) {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);

        startActivityForResult(Intent.createChooser(intent,"Select Picture"), Gallery_Code);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK)
        {
            if (requestCode == Gallery_Code)
            {
                selectedImageUri = data.getData();
                selectedImagePath = getPath(selectedImageUri);
                iv.setImageURI(selectedImageUri);
                iv.setDrawingCacheEnabled(true);
                bitmap = iv.getDrawingCache();

                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream);
                byte[] byteArray = byteArrayOutputStream .toByteArray();

                cover_page = Base64.encodeToString(byteArray, Base64.DEFAULT);
//                Toast.makeText(Add_book.this,cover_page.toString(),Toast.LENGTH_LONG).show();
            }
        }
    }
    public String getPath(Uri uri)
    {
        String[] projection = { MediaStore.Images.Media.DATA };
        Cursor cursor = managedQuery(uri, projection, null, null, null);
        if (cursor == null) return null;
        int column_index =  cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        String s=cursor.getString(column_index);
        cursor.close();
        return s;
    }

    public void submit(View view) {
        String title = btitle.getText().toString();
        String isbn = bisbn.getText().toString();
        String author = bauthor.getText().toString();
        String category = bcategory.getText().toString();
        String lang = blang.getText().toString();
        String edition = bedition.getText().toString();
        String date = bpublis.getText().toString();

        BackgroundWorker1 backgroundWorker = new BackgroundWorker1(this);
        backgroundWorker.execute("add_book",title,isbn,author,category,lang,edition,date,cover_page);
    }

    class BackgroundWorker1 extends AsyncTask<String ,Void ,String> {
        Context context;
        AlertDialog alertDialog;
        BackgroundWorker1(Context ctx){
            context = ctx;
        }
        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
        @Override
        protected String doInBackground(String... params) {
            String type = params[0];
            if(type.equals("add_book")){
                try {
                    String title = params[1];
                    String isbn = params[2];
                    String author = params[3];
                    String category = params[4];
                    String lang = params[5];
                    String edition = params[6];
                    String date = params[7];
                    String image = params[8];

                    String main_url = "https://datt07.000webhostapp.com/Admin_add_book.php";
                    URL url = new URL(main_url);
                    HttpURLConnection httpURLConnection = (HttpURLConnection)url.openConnection();
                    httpURLConnection.setRequestMethod("POST");
                    httpURLConnection.setDoOutput(true);
                    httpURLConnection.setDoInput(true);
                    OutputStream outputStream = httpURLConnection.getOutputStream();
                    BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                    String post_data = URLEncoder.encode("type", "utf-8") + "=" + URLEncoder.encode(type, "utf-8")+"&"
                            +URLEncoder.encode("btitle","UTF-8")+"="+URLEncoder.encode(title,"UTF-8")+"&"
                            +URLEncoder.encode("bisbn","UTF-8")+"="+URLEncoder.encode(isbn,"UTF-8")+"&"
                            +URLEncoder.encode("bauthor","UTF-8")+"="+URLEncoder.encode(author,"UTF-8")+"&"
                            +URLEncoder.encode("bcategory","UTF-8")+"="+URLEncoder.encode(category,"UTF-8")+"&"
                            +URLEncoder.encode("blang","UTF-8")+"="+URLEncoder.encode(lang,"UTF-8")+"&"
                            +URLEncoder.encode("bedition","UTF-8")+"="+URLEncoder.encode(edition,"UTF-8")+"&"
                            +URLEncoder.encode("bdate","UTF-8")+"="+URLEncoder.encode(date,"UTF-8")+"&"
                            +URLEncoder.encode("bimage","UTF-8")+"="+URLEncoder.encode(image,"UTF-8");
                    bufferedWriter.write(post_data);
                    bufferedWriter.flush();
                    bufferedWriter.close();
                    outputStream.close();
                    InputStream inputStream = httpURLConnection.getInputStream();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.ISO_8859_1));
                    String result="";
                    String line="";
                    while((line = bufferedReader.readLine())!= null) {
                        result += line;
                    }
                    Log.d("Sataus", "Accoutncreated3");
                    bufferedReader.close();
                    inputStream.close();
                    httpURLConnection.disconnect();
                    return result;
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }

        @Override
        protected void onPreExecute() {
            alertDialog = new AlertDialog.Builder(context).create();
        }

        @Override
        protected void onPostExecute(String result) {
            alertDialog.setMessage(result);
            alertDialog.show();
            Log.d("Sataus", result);
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }
    }
}