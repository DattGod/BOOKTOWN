package com.example.booktownadmin;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLEncoder;

import javax.net.ssl.HttpsURLConnection;

public class User_page extends AppCompatActivity implements userpageinterface{
    EditText username;
    RadioButton buyerrb,selllerrb,bothrb,nonerb;
    RecyclerView rv ;
    Button s;
    String u_name,u_role,data1[][];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_page);
        buyerrb = findViewById(R.id.R_buyer);
        selllerrb = findViewById(R.id.R_seller);
        bothrb = findViewById(R.id.R_both);
        nonerb = findViewById(R.id.R_none);
        rv = findViewById(R.id.rv);
        s = findViewById(R.id.search);
        username = findViewById(R.id.search_username);
//        username.setFocusable(false);

        BackgroundWorker bw = new BackgroundWorker(this);
        bw.execute("s");

    }

    public void search(View view) {

        u_name = username.getText().toString();
        if (!TextUtils.isEmpty(u_name)) {
            BackgroundWorker bw = new BackgroundWorker(this);
            bw.execute("u_name",u_name);
        }
        else if(buyerrb.isChecked()){
            u_role = "buyer";
            BackgroundWorker bw = new BackgroundWorker(this);
            bw.execute("u_role",u_role);
        }
        else if(selllerrb.isChecked()){
            u_role = "seller";
            BackgroundWorker bw = new BackgroundWorker(this);
            bw.execute("u_role",u_role);
        }
        else if(bothrb.isChecked()){
            u_role = "reseller";
            BackgroundWorker bw = new BackgroundWorker(this);
            bw.execute("u_role",u_role);
        }
        else if(nonerb.isChecked()){
            BackgroundWorker bw = new BackgroundWorker(this);
            bw.execute("s");
        }
        else{
            BackgroundWorker bw = new BackgroundWorker(this);
            bw.execute("s");
        }


    }

    public void delete(View view) {
        u_name = username.getText().toString();
        if (!TextUtils.isEmpty(u_name)) {
            BackgroundWorker bw = new BackgroundWorker(this);
            bw.execute("delete",u_name);
        }
        else{
            username.setError("Please enter your username");
            username.requestFocus();
        }
    }

    @Override
    public void onItemClick(int position) {
        AlertDialog alertDialog;
        alertDialog = new AlertDialog.Builder(this).create();

        String str = "User Name : "+data1[position][0]+"\n\nUser ID : "+data1[position][1]+"\n\nEmail : "+data1[position][2]+
                "\n\nPhone No-1 : "+data1[position][3]+"\n\nPhone No-2 : "+data1[position][4]+"\n\nAddress : "+data1[position][5];
        alertDialog.setMessage(str);
        alertDialog.show();
//        Toast.makeText(this,data1[position][0],Toast.LENGTH_LONG).show();
    }

    class BackgroundWorker extends AsyncTask<String, Void, user_info_Main>
    {
        String url = "", request = "", read = "",name,role,type;
        Context context;
        JSONArray jsonArray;
        user_info_Main user_info_main;
        int count1;
        BackgroundWorker(Context context)
        {
            this.context = context;
        }
        @Override
        protected user_info_Main doInBackground(String params[]) {
            try {
                type = params[0];
                if(type.equals("u_name")){
                    name = params[1];
                    url = "https://datt07.000webhostapp.com/Admin_user_info.php";
                    URL u = new URL(url);
                    HttpsURLConnection http_conn = (HttpsURLConnection) u.openConnection();
                    http_conn.setRequestMethod("POST");
                    BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(http_conn.getOutputStream(), "utf-8"));
                    bw= new BufferedWriter(new OutputStreamWriter(http_conn.getOutputStream(), "utf-8"));
                    request =URLEncoder.encode("type", "utf-8") + "=" + URLEncoder.encode(type, "utf-8")+"&"+
                            URLEncoder.encode("uname", "utf-8") + "=" + URLEncoder.encode(name, "utf-8");
                    bw.write(request);
                    bw.flush();
                    BufferedReader br = new BufferedReader(new InputStreamReader(http_conn.getInputStream(), "iso-8859-1"));
                    br = new BufferedReader(new InputStreamReader(http_conn.getInputStream(), "iso-8859-1"));
                    while((read = br.readLine()) != null)
                    {
                        jsonArray = new JSONArray(read);
                        count1 =   Integer.parseInt(jsonArray.getJSONObject(0).getString("count"));
                        Log.d("count", "5");


                    }
                    if(jsonArray != null)
                    {
                        data1 = new String[count1][7];
                        for (int i = 0 ; i < count1 ; i++) {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            data1[i][0] = jsonObject.getString("user_name");
                            data1[i][1] = jsonObject.getString("user_id");
                            data1[i][2] = jsonObject.getString("user_email");
                            data1[i][3] = jsonObject.getString("user_phone1");
                            data1[i][4] = jsonObject.getString("user_phone2");
                            data1[i][5] = jsonObject.getString("user_add");
//                        Log.d("Data",data1[i][0]);

                        }
                    }

                    bw.close();
                    br.close();

                }
                if(type.equals("u_role")){
                    role = params[1];
                    url = "https://datt07.000webhostapp.com/Admin_user_info.php";
                    URL u = new URL(url);
                    HttpsURLConnection http_conn = (HttpsURLConnection) u.openConnection();
                    http_conn.setRequestMethod("POST");
                    BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(http_conn.getOutputStream(), "utf-8"));
                    bw= new BufferedWriter(new OutputStreamWriter(http_conn.getOutputStream(), "utf-8"));
                    request =URLEncoder.encode("type", "utf-8") + "=" + URLEncoder.encode(type, "utf-8")+"&"+
                            URLEncoder.encode("urole", "utf-8") + "=" + URLEncoder.encode(role, "utf-8");
                    bw.write(request);
                    bw.flush();
                    BufferedReader br = new BufferedReader(new InputStreamReader(http_conn.getInputStream(), "iso-8859-1"));
                    br = new BufferedReader(new InputStreamReader(http_conn.getInputStream(), "iso-8859-1"));
                    while((read = br.readLine()) != null)
                    {
                        jsonArray = new JSONArray(read);
                        count1 =   Integer.parseInt(jsonArray.getJSONObject(0).getString("count"));
                        Log.d("count", String.valueOf(count1));


                    }
                    if(jsonArray != null)
                    {
                        data1 = new String[count1][7];
                        for (int i = 0 ; i < count1 ; i++) {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            data1[i][0] = jsonObject.getString("user_name");//change
                            data1[i][1] = jsonObject.getString("user_id");
                            data1[i][2] = jsonObject.getString("user_email");
                            data1[i][3] = jsonObject.getString("user_phone1");
                            data1[i][4] = jsonObject.getString("user_phone2");
                            data1[i][5] = jsonObject.getString("user_add");
//                        Log.d("Data",data1[i][0]);

                        }
                    }

                    bw.close();
                    br.close();

                }
                if(type.equals("s")){
                    url = "https://datt07.000webhostapp.com/Admin_user_info.php";
                    URL u = new URL(url);
                    HttpsURLConnection http_conn = (HttpsURLConnection) u.openConnection();
                    http_conn.setRequestMethod("POST");
                    BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(http_conn.getOutputStream(), "utf-8"));
                    bw= new BufferedWriter(new OutputStreamWriter(http_conn.getOutputStream(), "utf-8"));
                    request =URLEncoder.encode("type", "utf-8") + "=" + URLEncoder.encode(type, "utf-8");
                    bw.write(request);
                    bw.flush();
                    BufferedReader br = new BufferedReader(new InputStreamReader(http_conn.getInputStream(), "iso-8859-1"));
                    br = new BufferedReader(new InputStreamReader(http_conn.getInputStream(), "iso-8859-1"));
                    while((read = br.readLine()) != null)
                    {
                        jsonArray = new JSONArray(read);
                        count1 =   Integer.parseInt(jsonArray.getJSONObject(0).getString("count"));
                        Log.d("count", "5");


                    }
                    if(jsonArray != null)
                    {
                        data1 = new String[count1][7];
                        for (int i = 0 ; i < count1 ; i++) {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            data1[i][0] = jsonObject.getString("user_name");//change
                            data1[i][1] = jsonObject.getString("user_id");
                            data1[i][2] = jsonObject.getString("user_email");
                            data1[i][3] = jsonObject.getString("user_phone1");
                            data1[i][4] = jsonObject.getString("user_phone2");
                            data1[i][5] = jsonObject.getString("user_add");
//                        Log.d("Data",data1[i][0]);

                        }
                    }

                    bw.close();
                    br.close();
                }
                if(type.equals("delete")){
                    name = params[1];
                    url = "https://datt07.000webhostapp.com/admin_delete_user.php";
                    URL u = new URL(url);
                    HttpsURLConnection http_conn = (HttpsURLConnection) u.openConnection();
                    http_conn.setRequestMethod("POST");
                    BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(http_conn.getOutputStream(), "utf-8"));
                    bw= new BufferedWriter(new OutputStreamWriter(http_conn.getOutputStream(), "utf-8"));
                    request =URLEncoder.encode("type", "utf-8") + "=" + URLEncoder.encode(type, "utf-8")+"&"+
                            URLEncoder.encode("uname", "utf-8") + "=" + URLEncoder.encode(name, "utf-8");
                    bw.write(request);
                    bw.flush();
                    BufferedReader br = new BufferedReader(new InputStreamReader(http_conn.getInputStream(), "iso-8859-1"));
                    br = new BufferedReader(new InputStreamReader(http_conn.getInputStream(), "iso-8859-1"));
                    while((read = br.readLine()) != null)
                    {
                        jsonArray = new JSONArray(read);
                        count1 =   Integer.parseInt(jsonArray.getJSONObject(0).getString("count"));
                        Log.d("count", "5");


                    }
                    if(jsonArray != null)
                    {
                        data1 = new String[count1][7];
                        for (int i = 0 ; i < count1 ; i++) {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            data1[i][0] = jsonObject.getString("user_name");
                            data1[i][1] = jsonObject.getString("user_id");
                            data1[i][2] = jsonObject.getString("user_email");
                            data1[i][3] = jsonObject.getString("user_phone1");
                            data1[i][4] = jsonObject.getString("user_phone2");
                            data1[i][5] = jsonObject.getString("user_add");
//                        Log.d("Data",data1[i][0]);

                        }
                    }

                    bw.close();
                    br.close();

                }
            }
            catch(Exception e)
            {
                Log.d("Error", e.getMessage());
            }
            return user_info_main;
        }

        @Override
        protected void onPostExecute(user_info_Main user_info_main) {
            super.onPostExecute(user_info_main);
            rv.setLayoutManager(new LinearLayoutManager(context, LinearLayoutManager.VERTICAL,false));
            rv.setAdapter(new userAdapter(data1,User_page.this));
        }
    }
}
class user_info1
{
    Context ctx;
    String[][] s;

    user_info1(Context context, String[][] s)
    {
        this.s = s;
        Log.d("data",s[0][0]);
        Log.d("data",s[1][0]);
        ctx = context;

    }
}
class user_info_Main
{
     public static user_info1 userInfo1;

    user_info_Main(user_info1 u1)
    {

        userInfo1 = u1;

    }
}