package com.example.booktownadmin;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class login extends AppCompatActivity {

    EditText usernameET,passwET;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        usernameET = findViewById(R.id.username);
        passwET = findViewById(R.id.Password);

    }
    public void login(View view) {
        String username = usernameET.getText().toString();
        String password = passwET.getText().toString();
        String type = "login";

        if (TextUtils.isEmpty(username)) {
            usernameET.setError("Please enter your username");
            usernameET.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(password)) {
            passwET.setError("Please enter your password");
            passwET.requestFocus();
            return;
        }

        BackgroundWorker backgroundWorker = new BackgroundWorker(this);
        backgroundWorker.execute(type,username,password);
    }
}
class BackgroundWorker extends AsyncTask<String ,Void ,String> {
    Context context;
    android.app.AlertDialog alertDialog;
    String user_name;

    BackgroundWorker(Context ctx){
        context = ctx;
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected String doInBackground(String... params) {
        String type = params[0];
        user_name = params[1];
//       IP : 192.168.43.54
        if(type.equals("login")) {
            try {
                Log.d("status", "executing");
                String password = params[2];
                String main_url = "https://datt07.000webhostapp.com/admin_login.php";
                URL url = new URL(main_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection)url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String post_data = URLEncoder.encode("user_name","UTF-8")+"="+URLEncoder.encode(user_name,"UTF-8")+"&"
                        +URLEncoder.encode("u_password","UTF-8")+"="+URLEncoder.encode(password,"UTF-8");
                bufferedWriter.write(post_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.ISO_8859_1));
                String result="";
                String line="";
                while((line = bufferedReader.readLine())!= null) {
                    result += line;
                }
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return result;

            } catch (MalformedURLException e) {
                e.printStackTrace();
                Log.d("eRoor", e.getMessage());
            } catch (IOException e) {
                e.printStackTrace();
                Log.d("eRoor", e.getMessage());
            }
        }
        return null;
    }

    @Override
    protected void onPreExecute() {
        alertDialog = new android.app.AlertDialog.Builder(context).create();
    }

    @Override
    protected void onPostExecute(String result) {
        String str = result;
        alertDialog.setMessage(str);
        alertDialog.show();

        if (str.equals("login Successful...")) {

            Intent i = new Intent(context,Admin_home.class);
            i.putExtra("username",user_name);
            context.startActivity(i);

            alertDialog.setMessage(str);
            alertDialog.show();
        }

    }

    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
    }
}