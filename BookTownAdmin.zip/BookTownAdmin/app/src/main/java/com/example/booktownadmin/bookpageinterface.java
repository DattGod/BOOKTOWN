package com.example.booktownadmin;

public interface bookpageinterface {
    void onItemClick(int position);
}
