package com.example.booktownadmin;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLEncoder;

import javax.net.ssl.HttpsURLConnection;

public class book_page extends AppCompatActivity implements bookpageinterface{
    TextView username;
    RecyclerView rv ;
    String u_name,data1[][];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_page);

        rv = findViewById(R.id.rv);
        BackgroundWorker bw = new BackgroundWorker(this);
        bw.execute("s");
    }

    public void search(View view) {
        u_name = username.getText().toString();
        if (!TextUtils.isEmpty(u_name)) {
            BackgroundWorker bw = new BackgroundWorker(this);
            bw.execute("u_name",u_name);
        }
        else{
            BackgroundWorker bw = new BackgroundWorker(this);
            bw.execute("s");
        }
    }

    @Override
    public void onItemClick(int position) {
        AlertDialog alertDialog;
        alertDialog = new AlertDialog.Builder(this).create();

        String str = "Book ISBN : "+data1[position][0]+"\n\nBook Title : "+data1[position][2]+"\n\nBook Author : "+data1[position][3]+
                "\n\nBook Language : "+data1[position][4]+"\n\nPublis Year : "+data1[position][5]+"\n\nEdition : "+data1[position][6];
        alertDialog.setMessage(str);
        alertDialog.show();
//        Toast.makeText(this,data1[position][0],Toast.LENGTH_LONG).show();
    }

    class BackgroundWorker extends AsyncTask<String, Void,book_info_Main>
    {
        String url = "", request = "", read = "",name,type;
        Context context;
        JSONArray jsonArray;
        book_info_Main book_info_main;
        int count1;
        BackgroundWorker(Context context)
        {
            this.context = context;
        }
        @Override
        protected book_info_Main doInBackground(String params[]) {
            try {
                type = params[0];
                if(type.equals("u_name")){
                    name = params[1];
                    url = "https://datt07.000webhostapp.com/Admin_book_info.php";
                    URL u = new URL(url);
                    HttpsURLConnection http_conn = (HttpsURLConnection) u.openConnection();
                    http_conn.setRequestMethod("POST");
                    BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(http_conn.getOutputStream(), "utf-8"));
                    bw= new BufferedWriter(new OutputStreamWriter(http_conn.getOutputStream(), "utf-8"));
                    request = URLEncoder.encode("type", "utf-8") + "=" + URLEncoder.encode(type, "utf-8")+"&"+
                            URLEncoder.encode("bISBN", "utf-8") + "=" + URLEncoder.encode(name, "utf-8");
                    bw.write(request);
                    bw.flush();
                    BufferedReader br = new BufferedReader(new InputStreamReader(http_conn.getInputStream(), "iso-8859-1"));
                    br = new BufferedReader(new InputStreamReader(http_conn.getInputStream(), "iso-8859-1"));
                    while((read = br.readLine()) != null)
                    {
                        jsonArray = new JSONArray(read);
                        count1 =   Integer.parseInt(jsonArray.getJSONObject(0).getString("count"));
                        Log.d("count", "5");


                    }
                    if(jsonArray != null)
                    {
                        data1 = new String[count1][9];
                        for (int i = 0 ; i < count1 ; i++) {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            data1[i][0] = jsonObject.getString("book_ISBN");
                            data1[i][1] = jsonObject.getString("book_cate_id");
                            data1[i][2] = jsonObject.getString("book_title");
                            data1[i][3] = jsonObject.getString("book_author_name");
                            data1[i][4] = jsonObject.getString("book_language");
                            data1[i][5] = jsonObject.getString("book_date");
                            data1[i][6] = jsonObject.getString("book_edition");


                            data1[i][7] = jsonObject.getString("book_cover_page");//change
//                        Log.d("Data",data1[i][0]);

                        }
                    }

                    bw.close();
                    br.close();

                }

                if(type.equals("s")){
                    url = "https://datt07.000webhostapp.com/Admin_book_info.php";
                    URL u = new URL(url);
                    HttpsURLConnection http_conn = (HttpsURLConnection) u.openConnection();
                    http_conn.setRequestMethod("POST");
                    BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(http_conn.getOutputStream(), "utf-8"));
                    bw= new BufferedWriter(new OutputStreamWriter(http_conn.getOutputStream(), "utf-8"));
                    request =URLEncoder.encode("type", "utf-8") + "=" + URLEncoder.encode(type, "utf-8");
                    bw.write(request);
                    bw.flush();
                    BufferedReader br = new BufferedReader(new InputStreamReader(http_conn.getInputStream(), "iso-8859-1"));
                    br = new BufferedReader(new InputStreamReader(http_conn.getInputStream(), "iso-8859-1"));
                    while((read = br.readLine()) != null)
                    {
                        jsonArray = new JSONArray(read);
                        count1 =   Integer.parseInt(jsonArray.getJSONObject(0).getString("count"));
                        Log.d("count", "5");


                    }
                    if(jsonArray != null)
                    {
                        data1 = new String[count1][9];
                        for (int i = 0 ; i < count1 ; i++) {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            data1[i][0] = jsonObject.getString("book_ISBN");//change
                            data1[i][1] = jsonObject.getString("book_cate_id");
                            data1[i][2] = jsonObject.getString("book_title");
                            data1[i][3] = jsonObject.getString("book_author_name");
                            data1[i][4] = jsonObject.getString("book_language");
                            data1[i][5] = jsonObject.getString("book_date");
                            data1[i][6] = jsonObject.getString("book_edition");


                            data1[i][7] = jsonObject.getString("book_cover_page");

//                        Log.d("Data",data1[i][0]);

                        }
                    }

                    bw.close();
                    br.close();
                }
            }
            catch(Exception e)
            {
                Log.d("Error", e.getMessage());
            }
            return book_info_main;
        }

        @Override
        protected void onPostExecute(book_info_Main book_info_main) {
            super.onPostExecute(book_info_main);
            rv.setLayoutManager(new LinearLayoutManager(context, LinearLayoutManager.VERTICAL,false));
            rv.setAdapter(new bookAdapter(data1,book_page.this));
        }
    }
}
class book_info1
{
    Context ctx;
    String[][] s;

    book_info1(Context context, String[][] s)
    {
        this.s = s;
        ctx = context;

    }
}
class book_info_Main
{
    public static user_info1 userInfo1;

    book_info_Main(user_info1 u1)
    {

        userInfo1 = u1;

    }
}