package com.example.booktownadmin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class Admin_home extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_home);
    }

    public void viewusers(View view) {
        Intent i = new Intent(this, User_page.class);
        startActivity(i);
    }

    public void viewbooks(View view) {
        Intent i = new Intent(this, book_page.class);
        startActivity(i);
    }

    public void addBook(View view) {
        Intent i = new Intent(this, Add_book.class);
        startActivity(i);
    }

    public void verfiy_user(View view) {
        Intent i = new Intent(this, verfiy_user_page.class);
        startActivity(i);
    }
}