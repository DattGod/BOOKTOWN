package com.example.booktownadmin;

import android.graphics.BitmapFactory;
import android.net.Uri;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

public class bookAdapter extends RecyclerView.Adapter<bookAdapter.ProgViewHolder> {
    String[][] bookInfo1;
    private final bookpageinterface bookpageinterface;

    bookAdapter(String[][] bookInfo1,bookpageinterface bookpageinterface)
    {
        this.bookpageinterface=bookpageinterface;
        this.bookInfo1 = bookInfo1;
    }

    public ProgViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.book_view, parent, false);
        return new ProgViewHolder(view,bookpageinterface);
    }


    @Override
    public void onBindViewHolder(ProgViewHolder holder, int position) {

        holder.txt[0].setText( bookInfo1[position][2]);
        holder.txt[1].setText( "Author : "+bookInfo1[position][3]);
        holder.txt[2].setText( "Publish Year : "+bookInfo1[position][5]);
        holder.txt[3].setText( "Edition : "+bookInfo1[position][6]);
        holder.txt[4].setText( "Language : "+bookInfo1[position][4]);

        byte[] decodedString = Base64.decode(bookInfo1[position][7], Base64.DEFAULT);
        holder.iv.setImageBitmap(BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length));
    }

    @Override
    public int getItemCount() {
        return bookInfo1.length;
    }

    public class ProgViewHolder extends RecyclerView.ViewHolder{
        TextView txt[] = new TextView[9];
        ImageView iv ;
        public ProgViewHolder(View itemView,bookpageinterface bookpageinterface) {
            super(itemView);

            txt[0]= itemView.findViewById(R.id.Admin_book_title);
            txt[1] = itemView.findViewById(R.id.admin_book_author);
            txt[2] = itemView.findViewById(R.id.admin_book_date);
            txt[3] = itemView.findViewById(R.id.admin_book_edition);
            txt[4] = itemView.findViewById(R.id.admin_book_Lang);

            iv = itemView.findViewById(R.id.Admin_book_cover);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(bookAdapter.this.bookpageinterface != null){
                        int pos = getAdapterPosition();

                        if(pos != RecyclerView.NO_POSITION){
                            bookAdapter.this.bookpageinterface.onItemClick(pos);
                        }
                    }
                }
            });
        }
    }
}
