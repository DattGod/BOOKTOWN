package com.example.booktownadmin;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class verfiy_userAdapter extends RecyclerView.Adapter<verfiy_userAdapter.ProgViewHolder> {
    String[][] verfiyInfo1;
    private final verfiypageinterface verfiypageinterface;

    verfiy_userAdapter(String[][] verfiyInfo1,verfiypageinterface verfiypageinterface)
    {
        this.verfiypageinterface = verfiypageinterface;
        this.verfiyInfo1 = verfiyInfo1;
    }

    public ProgViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.verfiy_view, parent, false);
        return new ProgViewHolder(view,verfiypageinterface);
    }

    @Override
    public void onBindViewHolder(@NonNull ProgViewHolder holder, int position) {
        holder.txt[0].setText( "User Name : "+verfiyInfo1[position][0]);
        holder.txt[1].setText( "User ID : "+verfiyInfo1[position][1]);
    }

    @Override
    public int getItemCount() {
        return verfiyInfo1.length;
    }

public class ProgViewHolder extends RecyclerView.ViewHolder{
    TextView txt[] = new TextView[9];
    public ProgViewHolder(View itemView,verfiypageinterface verfiypageinterface) {
        super(itemView);

        txt[0]= itemView.findViewById(R.id.verfiy_view_username);
        txt[1]= itemView.findViewById(R.id.verfiy_view_userid);

        itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(verfiy_userAdapter.this.verfiypageinterface != null){
                    int pos = getAdapterPosition();

                    if(pos != RecyclerView.NO_POSITION){
                        verfiy_userAdapter.this.verfiypageinterface.onItemClick(pos);
                    }
                }
            }
        });

    }
}
}

