package com.example.booktownadmin;

public interface userpageinterface {
    void onItemClick(int position);
}
