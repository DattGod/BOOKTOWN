package com.example.booktownadmin;

public interface verfiypageinterface {
    void onItemClick(int position);
}
