package com.example.booktownadmin;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

import javax.net.ssl.HttpsURLConnection;

public class verfiy_user_page extends AppCompatActivity implements verfiypageinterface{
    EditText username;
    RecyclerView rv ;
    String u_name,data1[][];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verfiy_user_page);

        rv = findViewById(R.id.rv);
        username = findViewById(R.id.search_username);

        BackgroundWorker bw = new BackgroundWorker(this);
        bw.execute("s");
    }

    public void Decline_user(View view) {
        u_name = username.getText().toString();
        if (!TextUtils.isEmpty(u_name)) {
            Decline bw = new Decline(this);
            bw.execute(u_name);
        }

        BackgroundWorker bw = new BackgroundWorker(this);
        bw.execute("s");
    }

    public void Accept_user(View view) {
        u_name = username.getText().toString();
        if (!TextUtils.isEmpty(u_name)) {
            Accept bw = new Accept(this);
            bw.execute(u_name);
        }

        BackgroundWorker bw = new BackgroundWorker(this);
        bw.execute("s");
    }

    @Override
    public void onItemClick(int position) {
        AlertDialog alertDialog;
        alertDialog = new AlertDialog.Builder(this).create();

        String str = "User Name : "+data1[position][0]+"\n\nUser ID : "+data1[position][1]+"\n\nEmail : "+data1[position][2]+
                "\n\nPhone No-1 : "+data1[position][3]+"\n\nPhone No-2 : "+data1[position][4]+"\n\nAddress : "+data1[position][5]+"\n\nCompany Name: "+data1[position][12]+"\n\nRegistration ID : "+data1[position][6]+"\n\nRegistration Doc : "+data1[position][7]+"\n\nCompany No-1 : "+data1[position][8]+"\n\nCompany No-2 : "+data1[position][9]+"\n\nCompany Website : "+data1[position][10]+"\n\nCompany GST No : "+data1[position][11];
        alertDialog.setMessage(str);
        alertDialog.show();

    }

    class Accept extends AsyncTask<String ,Void ,String> {
        Context context;
        android.app.AlertDialog alertDialog;
        String user_name;

        Accept(Context ctx){
            context = ctx;
        }

        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
        @Override
        protected String doInBackground(String... params) {
            user_name = params[0];
//       IP : 192.168.43.54
                try {
                    Log.d("status", "executing");
                    String main_url = "https://datt07.000webhostapp.com/Accept.php";
                    URL url = new URL(main_url);
                    HttpURLConnection httpURLConnection = (HttpURLConnection)url.openConnection();
                    httpURLConnection.setRequestMethod("POST");
                    httpURLConnection.setDoOutput(true);
                    httpURLConnection.setDoInput(true);
                    OutputStream outputStream = httpURLConnection.getOutputStream();
                    BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                    String post_data = URLEncoder.encode("uname","UTF-8")+"="+URLEncoder.encode(user_name,"UTF-8");
                    bufferedWriter.write(post_data);
                    bufferedWriter.flush();
                    bufferedWriter.close();
                    outputStream.close();
                    InputStream inputStream = httpURLConnection.getInputStream();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.ISO_8859_1));
                    String result="";
                    String line="";
                    while((line = bufferedReader.readLine())!= null) {
                        result += line;
                    }
                    bufferedReader.close();
                    inputStream.close();
                    httpURLConnection.disconnect();
                    return result;

                } catch (MalformedURLException e) {
                    e.printStackTrace();
                    Log.d("eRoor", e.getMessage());
                } catch (IOException e) {
                    e.printStackTrace();
                    Log.d("eRoor", e.getMessage());
                }
            return null;
        }

        @Override
        protected void onPreExecute() {
            alertDialog = new android.app.AlertDialog.Builder(context).create();
        }

        @Override
        protected void onPostExecute(String result) {
            alertDialog.setMessage(result);
            alertDialog.show();
            }

        }


    class Decline extends AsyncTask<String ,Void ,String> {
        Context context;
        android.app.AlertDialog alertDialog;
        String user_name;

        Decline(Context ctx){
            context = ctx;
        }

        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
        @Override
        protected String doInBackground(String... params) {
            user_name = params[0];
//       IP : 192.168.43.54
            try {
                Log.d("status", "executing");
                String main_url = "https://datt07.000webhostapp.com/Decline.php";
                URL url = new URL(main_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection)url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String post_data = URLEncoder.encode("uname","UTF-8")+"="+URLEncoder.encode(user_name,"UTF-8");
                bufferedWriter.write(post_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.ISO_8859_1));
                String result="";
                String line="";
                while((line = bufferedReader.readLine())!= null) {
                    result += line;
                }
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return result;

            } catch (MalformedURLException e) {
                e.printStackTrace();
                Log.d("eRoor", e.getMessage());
            } catch (IOException e) {
                e.printStackTrace();
                Log.d("eRoor", e.getMessage());
            }
            return null;
        }

        @Override
        protected void onPreExecute() {
            alertDialog = new android.app.AlertDialog.Builder(context).create();
        }

        @Override
        protected void onPostExecute(String result) {
            alertDialog.setMessage(result);
            alertDialog.show();
        }

    }


    class BackgroundWorker extends AsyncTask<String, Void,verfiy_info_Main>
    {
        String url = "", request = "", read = "",type;
        Context context;
        JSONArray jsonArray;
        verfiy_info_Main verfiy_info_Main;
        int count1;
        BackgroundWorker(Context context)
        {
            this.context = context;
        }
        @Override
        protected verfiy_info_Main doInBackground(String params[]) {
            try {
                type = params[0];
                if(type.equals("s")){
                    url = "https://datt07.000webhostapp.com/Admin_verfiy_user.php";
                    URL u = new URL(url);
                    HttpsURLConnection http_conn = (HttpsURLConnection) u.openConnection();
                    http_conn.setRequestMethod("POST");
                    BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(http_conn.getOutputStream(), "utf-8"));
                    bw= new BufferedWriter(new OutputStreamWriter(http_conn.getOutputStream(), "utf-8"));
                    request =URLEncoder.encode("type", "utf-8") + "=" + URLEncoder.encode(type, "utf-8");
                    bw.write(request);
                    bw.flush();
                    BufferedReader br = new BufferedReader(new InputStreamReader(http_conn.getInputStream(), "iso-8859-1"));
                    br = new BufferedReader(new InputStreamReader(http_conn.getInputStream(), "iso-8859-1"));
                    while((read = br.readLine()) != null)
                    {
                        jsonArray = new JSONArray(read);
                        count1 =   Integer.parseInt(jsonArray.getJSONObject(0).getString("count"));
                        Log.d("count", "5");


                    }
                    if(jsonArray != null)
                    {
                        data1 = new String[count1][15];
                        for (int i = 0 ; i < count1 ; i++) {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            data1[i][0] = jsonObject.getString("user_name");
                            data1[i][1] = jsonObject.getString("user_id");
                            data1[i][2] = jsonObject.getString("user_email");
                            data1[i][3] = jsonObject.getString("user_phone1");
                            data1[i][4] = jsonObject.getString("user_phone2");
                            data1[i][5] = jsonObject.getString("user_phone2");
                            data1[i][6] = jsonObject.getString("company_reg_id");
                            data1[i][7] = jsonObject.getString("company_reg_doc");
                            data1[i][8] = jsonObject.getString("company_phone1");
                            data1[i][9] = jsonObject.getString("company_phone2");
                            data1[i][10] = jsonObject.getString("company_website");
                            data1[i][11] = jsonObject.getString("GST");
                            data1[i][12] = jsonObject.getString("company_name");

    //                        Log.d("Data",data1[i][0]);

                        }
                    }

                    bw.close();
                    br.close();
                }
            }
            catch(Exception e)
            {
                Log.d("Error", e.getMessage());
            }
            return verfiy_info_Main;
        }

        @Override
        protected void onPostExecute(verfiy_info_Main verfiy_info_Main) {
            super.onPostExecute(verfiy_info_Main);
            rv.setLayoutManager(new LinearLayoutManager(context, LinearLayoutManager.VERTICAL,false));
            rv.setAdapter(new verfiy_userAdapter(data1,verfiy_user_page.this));
        }
    }
}
class verfiy_info1
{
    Context ctx;
    String[][] s;

    verfiy_info1(Context context, String[][] s)
    {
        this.s = s;
        ctx = context;

    }
}
class verfiy_info_Main
{
    public static user_info1 userInfo1;

    verfiy_info_Main(user_info1 u1)
    {

        userInfo1 = u1;

    }
}