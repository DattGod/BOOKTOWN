package com.example.booktownadmin;


import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

public class userAdapter extends RecyclerView.Adapter<userAdapter.ProgViewHolder> {
    String[][] userInfo1;
    private final  userpageinterface userpageinterface;

    userAdapter(String[][] userInfo1,userpageinterface userpageinterface)
    {
        this.userInfo1 = userInfo1;
        this.userpageinterface = userpageinterface;
    }

    public ProgViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.user_view, parent, false);
        return new ProgViewHolder(view,userpageinterface);

    }

    @Override
    public void onBindViewHolder(ProgViewHolder holder, int position) {
//        Log.d("Data",userInfo1.s[position][0]);

        holder.txt[0].setText( "User Name : "+userInfo1[position][0]);
        holder.txt[1].setText( "User ID : "+ userInfo1[position][1]);

    }

    @Override
    public int getItemCount() {
        return userInfo1.length;
    }

    public class ProgViewHolder extends RecyclerView.ViewHolder{
        TextView txt[] = new TextView[5];
        public ProgViewHolder(View itemView, com.example.booktownadmin.userpageinterface userpageinterface) {
            super(itemView);
            txt[0]= itemView.findViewById(R.id.user_view_username);
            txt[1]= itemView.findViewById(R.id.user_view_userid);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(userAdapter.this.userpageinterface != null){
                        int pos = getAdapterPosition();

                        if(pos != RecyclerView.NO_POSITION){
                            userAdapter.this.userpageinterface.onItemClick(pos);
                        }
                    }
                }
            });
        }
    }
}
